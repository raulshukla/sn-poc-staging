import React from "react";
import { Label } from "../ui/label";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { SendIcon } from "lucide-react";

export default function ChatInput() {
  return (
    <div className="bg-white bottom-0 w-full flex flex-row justify-between gap-4 p-6 items-end border-t">
      <div className="w-full">
        <Label className="text-[12px] px-3">Ask a question or provide a prompt...</Label>
        <Input
          className="rounded-[24px] h-[59px] text-[14px] px-5"
          placeholder="Type here..."
        />
      </div>
      <Button className="h-[59px] rounded-[12px] px-6 w-[126px] text-[14px]">
        Submit <SendIcon />
      </Button>
    </div>
  );
}

export function UserMessage({ message }: { message: string }) {
  return (
    <div className="ml-6 text-white text-[14px] font-[400] bg-primary rounded-[16px] px-3 py-2">
      {message}
    </div>
  );
}

export function AIMessage({ message }: { message: string }) {
    return (
      <div className="mr-6 text-[14px] font-[400] bg-secondary rounded-[16px] px-3 py-2">
        {message}
      </div>
    );
  }