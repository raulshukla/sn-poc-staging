"use client";
import LandingPage from "./LandingPage";

export default function Page() {
  return <LandingPage />;
}
