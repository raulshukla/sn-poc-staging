// import { Analytics } from "@vercel/analytics/react";
import { Inter } from "next/font/google";
// import { SpeedInsights } from "@vercel/speed-insights/next";
import type { Metadata } from "next";
import SideBar from "@/components/sidebar/sidebar";
import { Header } from "@/components/header/header";
import ChatInput from "@/components/chat/chat";
const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Smokin'Notes",
  description: "Educational Platform",
  robots: "noindex, nofollow",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <div className="min-h-screen h-screen flex flex-col">
      <Header />
      <div className="flex-grow flex flex-row h-full">
        <SideBar />
        <div className={`w-full h-full max-h-full flex flex-col justify-between`}>
          <div className="flex-grow h-0">{children}</div>
          <ChatInput />
        </div>
      </div>
      {/* <SpeedInsights />
      <Analytics /> */}
    </div>
  );
}
